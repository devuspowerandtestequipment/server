exports.calculateTaxFunction = function(item){



  return 111;
};
